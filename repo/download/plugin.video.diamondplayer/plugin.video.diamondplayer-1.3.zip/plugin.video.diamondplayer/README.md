# plugin.video.diamondplayer
diamondplayer Kodi Add-on
